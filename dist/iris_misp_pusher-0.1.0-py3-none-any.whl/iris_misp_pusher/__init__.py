#!/usr/bin/env python3
#
#
#  IRIS misp Source Code
#  Copyright (C) 2025 - iris-misp-pusher
#  thienlai159@gmail.com
#  Created by iris-misp-pusher - 2025-10-15
#
#  License MIT

__iris_module_interface = "IrisMispInterface"